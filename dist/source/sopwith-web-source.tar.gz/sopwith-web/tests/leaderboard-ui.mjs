// SPDX-License-Identifier: GPL-2.0-or-later
// Exercise production score rendering with a full board and a nonqualifying run.
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
const elements=new Map(),events={},storage=new Map(),dispatched=[];
const element=()=>({children:[],value:'',listeners:{},append(...nodes){for(const node of nodes){if(node.parentElement)node.parentElement.children=node.parentElement.children.filter(n=>n!==node);node.parentElement=this;this.children.push(node);}},replaceChildren(){for(const child of this.children)child.parentElement=null;this.children=[];},addEventListener(name,fn){this.listeners[name]=fn;}});
const get=id=>{if(!elements.has(id))elements.set(id,element());return elements.get(id);};
const rows=Array.from({length:20},(_,i)=>({nickname:'T'+String(i+1).padStart(2,'0'),score:(20-i)*1000,level:2,runId:'old-'+i,finished_at:i}));
storage.set('sopwith.scores.rainbow.practice',JSON.stringify(rows));get('scores-mode').value='practice';get('game').src='runner.html?mode=practice&run=new-run';get('game').contentWindow={};
const scope={document:{body:{dataset:{edition:'rainbow',layout:'arcade'}},getElementById:get,createElement:element},location:{origin:'https://test.invalid',href:'https://test.invalid/rainbow.html'},URL,console,
 localStorage:{getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,value)},fetch:async()=>({json:async()=>({endpoint:null})}),setInterval(){},CustomEvent:class{constructor(type){this.type=type;}},window:{addEventListener:(name,fn)=>events[name]=fn,dispatchEvent:event=>dispatched.push(event.type)}};
vm.runInNewContext(await readFile(new URL('../dist/leaderboard.js',import.meta.url),'utf8'),scope);
const settle=()=>new Promise(resolve=>setImmediate(resolve));await settle();
assert.equal(get('scores-rows').children.length,10,'A full stored board displays only the top ten.');
assert.equal(get('scores-rows').children.at(-1).children[1].textContent,'T10');
const message=data=>events.message({origin:scope.location.origin,source:get('game').contentWindow,data:{sopwith:true,...data}});
message({type:'ready'});await settle();get('score-name').value='NEW';
message({type:'score-ready',score:500,level:2,ticks:1000,trainerUsed:false});await settle();
assert.equal(get('entry-scores-rows').children.length,10,'The initials background also has only ten rows.');
assert.equal(get('entry-rank').textContent,'SIJOITUS: 21','A lower score retains its actual rank without adding an eleventh row.');
const current=get('entry-scores-rows').children.find(row=>row.className==='current');
assert.equal(current.children[0].textContent,'21');
assert.equal(current.children[1].children[0],get('score-initials'),'The real editor occupies the score’s actual name cell.');
assert.equal(get('entry-scores-rows').children[0].children[0].textContent,'12','A lower-rank window keeps ten contiguous actual ranks.');
const rowBeforeEdit=current;get('score-name').value='XYZ';
if(events['sopwith-initials'])events['sopwith-initials']();
assert.equal(get('entry-scores-rows').children.find(row=>row.className==='current'),rowBeforeEdit,'Typing must not rebuild the table and lose focus.');
await get('score-form').listeners.submit({preventDefault(){}});
assert.equal(get('scores-rows').children.length,10);assert.ok(dispatched.includes('sopwith-score-saved'));
assert.equal(get('score-initials').parentElement,get('initials-parking'),'Saving parks the same editor for the next run.');
console.log('Arcade board: top ten in both views, inline three-character editor, contiguous lower-rank window, stable edit focus and safe save verified.');
get('game').src='runner.html?mode=practice&run=trainer-run';message({type:'ready'});await settle();
const saved=storage.get('sopwith.scores.rainbow.practice');
message({type:'trainer-state',enabled:true});message({type:'trainer-state',enabled:false});
message({type:'score-ready',score:999999,level:2,ticks:1000,trainerUsed:false});await settle();
assert.equal(get('score-form').hidden,true);assert.equal(storage.get('sopwith.scores.rainbow.practice'),saved);
assert.match(get('scores-status').textContent,/Trainer/);
console.log('Trainer score eligibility: enabling then disabling mid-flight still excludes the run.');
get('game').src='runner.html?mode=practice&difficulty=easy&run=easy-run';message({type:'ready'});await settle();
get('score-name').value='NEW';message({type:'score-ready',score:750,level:2,ticks:1000,trainerUsed:false});await settle();
assert.equal(get('entry-rank').textContent,'SIJOITUS: 1','Easy starts with its own board.');
await get('score-form').listeners.submit({preventDefault(){}});
assert.equal(JSON.parse(storage.get('sopwith.scores.rainbow.practice.easy'))[0].score,750);
assert.equal(storage.get('sopwith.scores.rainbow.practice'),saved,'Existing normal scores remain intact.');
get('scores-difficulty').value='normal';get('scores-difficulty').listeners.change();await settle();
assert.equal(get('scores-rows').children[0].children[1].textContent,'T01');
console.log('Difficulty boards: easy and normal stay separate; existing normal data and filters are preserved.');

get('game').src='runner.html?mode=practice&difficulty=normal&wingman=1&run=wingman-run';message({type:'ready'});await settle();
get('score-name').value='ACE';message({type:'score-ready',score:50000,level:3,ticks:1000,trainerUsed:false});await settle();
assert.equal(get('entry-rank').textContent,'SIJOITUS: 1');
await get('score-form').listeners.submit({preventDefault(){}});
assert.equal(JSON.parse(storage.get('sopwith.scores.rainbow.practice.wingman'))[0].score,50000);
assert.equal(storage.get('sopwith.scores.rainbow.practice'),saved,'Escort assistance never enters the solo board.');
get('scores-crew').value='solo';get('scores-crew').listeners.change();await settle();assert.equal(get('scores-rows').children[0].children[1].textContent,'T01');
console.log('Wingman results persist on a separate local board; crew filtering preserves solo scores.');

get('game').src='runner.html?mode=practice&difficulty=normal&supplies=1&trainer=0&run=supplies-run';message({type:'ready'});await settle();
get('score-name').value='INF';message({type:'score-ready',score:45000,level:3,ticks:1000,trainerUsed:false,suppliesUsed:true});await settle();
assert.equal(get('score-form').hidden,false);assert.equal(get('scores-rules').value,'supplies');
await get('score-form').listeners.submit({preventDefault(){}});
assert.equal(JSON.parse(storage.get('sopwith.scores.rainbow.practice.supplies'))[0].nickname,'INF');
assert.equal(storage.get('sopwith.scores.rainbow.practice'),saved,'Infinite supplies never changes the normal board.');
get('game').src='runner.html?mode=practice&run=late-supplies';message({type:'ready'});await settle();
message({type:'supplies-state',enabled:true});message({type:'supplies-state',enabled:false});
get('score-name').value='MID';message({type:'score-ready',score:46000,level:3,ticks:1000,trainerUsed:false});await settle();
await get('score-form').listeners.submit({preventDefault(){}});
assert.equal(JSON.parse(storage.get('sopwith.scores.rainbow.practice.supplies'))[0].nickname,'MID','A mid-flight supply cheat remains on its own board after disabling.');
const beforeDemo=[...storage.entries()];
get('game').src='runner.html?mode=combat&trainer=1&demo=1&run=demo';message({type:'ready'});await settle();
message({type:'score-ready',score:9999999,level:3,ticks:1000,trainerUsed:false});await settle();
assert.equal(get('score-form').hidden,true);assert.deepEqual([...storage.entries()],beforeDemo,'Attract demos never save any score.');
console.log('Infinite supplies have a separate persisted board; mid-flight changes are latched; demos cannot save scores.');

// Repeat the assisted save with a configured shared service: neither supply
// runs nor demos may create a server ticket or submit to the standard board.
const calls=[];scope.AbortSignal=AbortSignal;
scope.fetch=async(url,options={})=>{calls.push({url,method:options.method});return {ok:true,json:async()=>url.startsWith('leaderboard-config')?{endpoint:'https://scores.test'}:url.endsWith('/api/runs')?{id:'ticket',token:'token'}:{scores:[]}};};
get('scores-rules').value='supplies';get('game').src='runner.html?mode=practice&supplies=1&run=shared-supply-test';
vm.runInNewContext(await readFile(new URL('../dist/leaderboard.js',import.meta.url),'utf8'),scope);await settle();
message({type:'ready'});await settle();get('score-name').value='LOC';
message({type:'score-ready',score:900,level:2,ticks:1000,trainerUsed:false,suppliesUsed:true});await settle();
await get('score-form').listeners.submit({preventDefault(){}});
assert.equal(calls.some(c=>c.method==='POST'),false,'Supply runs never create a shared ticket or upload any score.');
get('game').src='runner.html?mode=combat&demo=1&run=shared-demo-test';message({type:'ready'});await settle();
assert.equal(calls.some(c=>c.method==='POST'),false,'Demo runs never create shared tickets.');
console.log('Configured shared service: assisted supply results and demos cannot issue run tickets or submit to normal shared scores.');
