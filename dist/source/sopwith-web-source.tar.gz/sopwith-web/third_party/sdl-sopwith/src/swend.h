//
// Copyright(C) 1984-2000 David L. Clark
// Copyright(C) 2001-2005 Simon Howard
//
// You can redistribute and/or modify this program under the terms of the
// GNU General Public License version 2 as published by the Free Software
// Foundation, or any later version. This program is distributed WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.
//

#ifndef __SWEND_H__
#define __SWEND_H__

#include "sw.h"

extern void swend(char *msg, bool update);
extern void endgame(faction_t winner);
extern void winner(OBJECTS *obp);
extern void loser(OBJECTS *ob);
extern void dispendmessage(void);

#endif
